import uuid

print(str(uuid.uuid4())[:8])